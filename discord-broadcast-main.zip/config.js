module.exports = {
    bot: {
        tokens: [
        //    "MTM4MzU5MDc0NzAzODU0ODA2MA.GoXhwy.8cdcmAUKBWTB1QmZcdn3IaiOJKodKCkk1IQ5wk",       // Main bot token - Replace with your actual token
        //    "MTM4MzU5MDc4MzI1NjYyOTI2OA.GLWvzX.GIoiHOmgC9kzfS7pPM8xNERlO8qKe1m_FK6OSM",       // 2 bot token - Uncomment and replace to use
        //    "MTM4MzU5MDgzMzQwMzU5Mjg0NA.GVDCaP.e12dSzhxHqzTh7H_k8ZFOICMFBK4UiY5jnHEn4",       // 3 bot token - Uncomment and replace to use
            "MTM4MzU5MDg2NjcyMzI3NDg4NA.GHT0aw.liUWkVfXogF-eXHptjAi8KwhMnmnwoJhilCtLc",       // 4 bot token - Uncomment and replace to use
            "MTM4MzU5MjUzNzU2NjA4NTI4Mg.GTGj1W.hwsAlHVMj0Pga4wRQPkv30oiDnzlQjYZIfBcHU",       // 5 bot token - Uncomment and replace to use
            "MTM4MzU5MjU1Njc0MjU3ODIyNw.GwySUx.w3sgnrd0cmeTWtiSpyMEhENLIK7SKTxvVO6AV0",  // 6th bot token - Replace with your actual token
            "MTM4MzU5MjYwNDY2MjUwMTQwNg.GnqkH6.ORre28ukxC0TM-_0TGU1nzv9d4wgmTJ1eFkOyM",  // 7th bot token - Replace with your actual token
            "MTM4MzU5MjY1OTM2MDE1Nzc3Ng.GJCskz.fOM4_GugWaOqXN_4wiVMVbGjBleU9jo1REkpf4",  // 8th bot token - Replace with your actual token
        //    "MTM4MzI2NTE4MzM3OTc1MTAyNg.GtmP29._h9L_3doN_mEBmI019Jz_HkkWKeVWAMB7RrVOk",  // 9th bot token - Replace with your actual token
        //    "MTM4MzI2NjcyNzMwMjc5MTE4OA.Gj1Zjg.-XWYrhIZj1In2McdfLm6-o2aEIOzlKK_awatGM", // 10th bot token - Replace with your actual token
        ].filter(Boolean), // .filter(Boolean) بتشيل أي قيم فاضية أو null لو نسيت تحط توكن

        defaultLanguage: 'en', // ar | en لغة البوت

        activity: {
            name: '𝐊𝐀𝐑𝐔𝐎𝐊𝐄_☪', // رسالة حالة البوت
            type: 'LISTENING', // PLAYING, STREAMING, LISTENING, WATCHING, COMPETING
            status: 'dnd' // online, idle, dnd, invisible
        }
    },
    server: {
        guildId: '614111404747915268',         // ايدي السيرفر
        broadcastRoleId: '1125216909034520626', // ايدي الرول اللي يستخدم عليها البوت
        reportChannelId: '1378401100947783792' // ايدي الروم اللي يرسل فيه البوت التقارير
    },
    broadcast: {
        cooldownTime: 1000, // لا تلعب فيها
        memberCooldown: 100, // لا تلعب فيها
        requestsPerSecond: 1 // لا تلعب فيها
    },

    colors: {
        primary: '#5865F2',    // Discord Blue (used for standard messages)
        success: '#57F287',    // Green (used for successful operations)
        warning: '#FEE75C',    // Yellow (used for warnings)
        error: '#ED4245',      // Red (used for errors)
        neutral: '#5D5D5D'     // Gray (used for neutral messages)
    }
};